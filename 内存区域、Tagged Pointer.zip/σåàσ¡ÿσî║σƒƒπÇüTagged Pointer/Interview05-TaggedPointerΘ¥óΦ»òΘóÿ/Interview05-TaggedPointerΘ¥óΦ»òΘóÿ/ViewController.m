//
//  ViewController.m
//  Interview05-TaggedPointer面试题
//
//  Created by MJ Lee on 2018/6/21.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (copy, nonatomic) NSString *name;
@end

@implementation ViewController

////MRC中setter方法
//- (void)setName:(NSString *)name
//{
//    if (_name != name) {
//        [_name release]; //先释放旧的
//        _name = [name copy]; //再赋值新的
//    }
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);

    for (int i = 0; i < 1000; i++) {
        dispatch_async(queue, ^{
            // 在这里加锁
            self.name = [NSString stringWithFormat:@"abcdefghijk"];
            // 在这里解锁
        });
    }
//
//    坏内存访问错误
//    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
//
//    for (int i = 0; i < 1000; i++) {
//        dispatch_async(queue, ^{
//            self.name = [NSString stringWithFormat:@"abc"];
//        });
//    }
    
//    [_name release]; //先释放旧的   释放了两次
    
    
//    解决办法：
//    1.改成atomic
//    2.加锁
// 加锁
//self.name = [NSString stringWithFormat:@"abcdefghijk"];
//// 解锁
    
//    为什么变成abc就不崩溃？ //    不是OC对象，不会调用setter方法。
    
    NSString *str1 = [NSString stringWithFormat:@"abcdefghijk"];
    NSString *str2 = [NSString stringWithFormat:@"abc"];
    
    NSLog(@"%@ %@", [str1 class], [str2 class]);// __NSCFString NSTaggedPointerString
    NSLog(@"%p %p",str1, str2); //0x6000037fa1a0 0xec1baa29b42aee38
    //最高位是1,或者用class证明
}

@end
