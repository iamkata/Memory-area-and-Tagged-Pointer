//
//  main.m
//  Interview04-TaggedPointer
//
//  Created by MJ Lee on 2018/6/21.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

BOOL isTaggedPointer(id pointer)
{
    return (long)(__bridge void *)pointer & 1;
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        //完整写法
//        NSNumber *number = [NSNumber numberWithInt:10];
//        //简写
//        NSNumber *number = @10;
        
        NSNumber *number1 = @4;
        NSNumber *number2 = @5;
        NSNumber *number3 = @(0xFFFFFFFFFFFFFFF); //数字很大
        
//        [number1 intValue];
//        objc_msgSend(number1, @selector(intValue));
//        number1.intValue;
        
//        NSLog(@"%d %d %d", isTaggedPointer(number1), isTaggedPointer(number2), isTaggedPointer(number3));
//        打印：1 1 0
        
        NSLog(@"%p %p %p", number1, number2, number3);
//        0x77f92be9bdbfa067 0x77f92be9bdbfa167 0x100575490
//        0b0111 0b0000
    }
    return 0;
}
